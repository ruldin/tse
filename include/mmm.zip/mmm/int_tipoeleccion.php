<?php
session_start();
include 'class.inputfilter_clean.php';
$xss = new InputFilter();
$_POST = $xss->process($_POST);

$_SESSION['TIPOELECCION']=$_POST['int_tipoeleccion'];
?>