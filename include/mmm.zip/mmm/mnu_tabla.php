<?php
include_once('../../include/conexion.php');
include_once('../../include/config.php');

class cls_tabla {
private $maxPartidos=MAX_PARTIDOS;
private $proceso=PROCESO;
private $ors;
	
	function __construct($dep,$mun,$tipoeleccion) {
		$cdb = new cbase;
		$cdb->conectaDB();
	/*if(version_compare(phpversion(),"4.3.0", ">")){
		$dep=mysql_escape_string($dep);
                $mun=mysql_escape_string($mun);
                $tipoeleccion=mysql_escape_string($tipoeleccion);
                $this->proceso=mysql_escape_string($this->proceso);

	}else{
		$dep=mysql_real_escape_string($dep);
                $mun=mysql_real_escape_string($mun);
                $tipoeleccion=mysql_real_escape_string($tipoeleccion);
                $this->proceso=mysql_real_escape_string($this->proceso);
	}*/
	
		/* inicio de filtro consultas */
		include '../../include/filtro.php';
		$dep=filtroConsulta($dep,2);
		$mun=filtroConsulta($mun,2);
		$tipoeleccion=filtroConsulta($tipoeleccion,2);
		$this->proceso=filtroConsulta($this->proceso,6);
		/* fin de filtro consultas */

		/* incio de filtro consulta */
		// filtros php
		$poner = array('','','','','','','');
		$quitar1 = array('+','union','all','%','?',' ','=');
		$quitar2 = array('-','_','a','e','i','o','u');
		// pasamos 2 filtros a las variables
		$dep = str_replace($quitar1,$poner,$dep);
		$dep = str_replace($quitar2,$poner,$dep);

		$mun = str_replace($quitar1,$poner,$mun);
		$mun = str_replace($quitar2,$poner,$mun);
		
		$tipoeleccion = str_replace($quitar1,$poner,$tipoeleccion);
		$tipoeleccion = str_replace($quitar2,$poner,$tipoeleccion);
		
		$this->proceso = str_replace($quitar1,$poner,$this->proceso);
		$this->proceso = str_replace($quitar2,$poner,$this->proceso);
		
		// consultamos si cada dato es numerico
		if (is_numeric($dep) && is_numeric($mun) && is_numeric($tipoeleccion) && is_numeric($this->proceso)){
			// realizamos el segundo filtro, cortar las variables
			$dep = substr($dep,0,2);
			$mun = substr($mun,0,2);
			$tipoeleccion = substr($tipoeleccion,0,2);
			$this->proceso = substr($this->proceso,0,6);
		} else {
			$dep = substr($dep,0,2);
			$mun = substr($mun,0,2);
			$tipoeleccion = substr($tipoeleccion,0,2);
			$this->proceso = substr($this->proceso,0,6);
		}
		/* fin de filtro consulta */	
		$this->ors= $cdb->consulta("SELECT * FROM tresultado WHERE DEP=".$dep." and MUN=" .$mun." and TIPOELECCION=".$tipoeleccion." and PROCESO=".$this->proceso);
		if ($cdb->N()==0)
		{
			$html='No hay datos.';
		}
		else
		{
			$html='<table class="tabla">';
			$i=0;
			$html.='<thead><tr><th class="header1">Partido</th><th class="header2">Votos</th><th class="header3">%</th></tr></thead><tbody>';
			while ( $i< $this->maxPartidos && $this->ors[11 +($i*5)]<>'' ) {
			   if(($i/2-round($i/2,0))==0) $tclass='';
			   else $tclass ='class="odd"';
			   $html.='<tr '.$tclass.'><td>'.$this->ors[11+($i*5)].'</td><td>'.$this->ors[13+($i*5)].'</td><td>'.number_format($this->ors[14+($i*5)],2).'</td></tr>';
			   $i++;
			}
			$html.='</tbody></table><br/>';

			// COLUMNAS DE TABLA PARA TOTALES
			$html.='<table class="tabla2"><caption>Totales</caption><tbody>';
			$html.='<tr class="totpar"><td class="c1">Votos V&aacute;lidos:</td><td class="c2">'.$this->ors['VOTOSVALIDOS'].'</td><td class="c3"></td></tr>';
			$html.='<tr class="totimpar"><td class="c1">Votos Blancos:</td><td class="c2">'.$this->ors['BLANCOS'].'</td><td class="c3">'.number_format($this->ors['PBLANCOS'],2).'</td></tr>';
			$html.='<tr class="totpar"><td class="c1">Votos Nulos:</td><td class="c2">'.$this->ors['NULOS'].'</td><td class="c3">'.number_format($this->ors['PNULOS'],2).'</td></tr>';
			$html.='<tr class="totimpar"><td class="c1">Votos Emitidos:</td><td class="c2">'.$this->ors['TOTALVOTOS'].'</td><td class="c3"></td></tr>';
			$html.='<tr class="totpar"><td class="c1">Votantes Inscritos:</td><td class="c2">'.$this->ors['CNTVOTANTES'].'</td><td class="c3"></td></tr>';
			$html.='<tr class="totimpar"><td title="Juntas Receptoras de Votos Totalizadas" class="c1">JRV Totalizadas:</td><td class="c2">'.$this->ors['MESASPRO'].'</td><td class="c3">'.number_format($this->ors['PMESASPRO'],2).'</td></tr>';
			$html.='<tr class="totpar"><td title="Total Juntas Receptoras de Votos" class="c1">Total JRV:</td><td class="c2">'.$this->ors['CNTMESAS'].'</td><td class="c3"></td></tr>';
			$html.='</tbody></table>';
		}
		echo $html;
	}
}
?>
