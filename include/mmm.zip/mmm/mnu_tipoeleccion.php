<?php
class vec_tipoeleccion {
	function __construct() {
	}
    function nombreeleccion() {
         return array ( 1 => 'Presidente y Vicepresidente', 2 => 'Diputados por Lista Nacional' );
    }
    function __destruct() {
	}
}

class cls_tipoeleccion {
   
	function __construct() {
		echo $this->combo();
	} 
    
	function combo() {
       $tmp = new vec_tipoeleccion(); 
	   $vec = $tmp->nombreeleccion();
	   $html='Tipo Elecci&oacute;n:<br/><select name="cmb_tipoeleccion" onChange="ajx_tipoeleccion(document.formulario.cmb_tipoeleccion.options[document.formulario.cmb_tipoeleccion.selectedIndex].value)">';
       $i=1;
       while($i <= count($vec)) {
            $html.='<option value="'.$i.'">'.$vec[$i].'</option>';
 		    $i++;
       }
	   $html.='</select>';
	   return $html;
	}  
}
?>