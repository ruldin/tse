<?php
session_start();
include 'mnu_depmun.php';
include 'class.inputfilter_clean.php';
$xss = new InputFilter();
$_POST = $xss->process($_POST);

$_SESSION['TITULO']='<b>Departamento:</b> '.$_POST['int_titulo'].'<b>';
$_SESSION['DEPARTAMENTO']=$_POST['int_dep'];
$_SESSION['MUNICIPIO']=0;

$tmp = new cls_depmun($_SESSION['TIPOELECCION'],$_POST['int_dep'],0,'ajx_mun',0);
?>

