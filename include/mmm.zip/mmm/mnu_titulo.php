<?php
class cls_titulo {
private $vec= array ( 1 => 'Presidente y Vicepresidente', 2 => 'Diputados por Lista Nacional', 
                      3 => 'Diputados por Distrito', 4 => 'Corporaci&oacute;n Municipal', 
                      5 => 'Diputados al Parlamento Centroamericano' );
   
	function __construct($te,$depmun,$fechahora) {
		$html='<table><tr><td class="t1">'.$this->vec[$te].'</td></tr>';
		$html.='<tr><td class="t2">'.$depmun.'</td></tr>';
		$html.='<tr><td class="t3">Resultados preliminares '.$fechahora.'</td></tr></table>';
		echo $html;
	} 
	
	function __desctruct() {
	}
}
?>