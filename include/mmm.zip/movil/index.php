<?php
// define tipo de eleccion
	if (isset($_REQUEST['tipoeleccion'])){ $tipoeleccion = $_REQUEST['tipoeleccion'];} else { $tipoeleccion = 1;}
// define ubicacion
	if (isset($_REQUEST['ubicacion'])){
		$ubicacion = $_REQUEST['ubicacion'];
	} else {
		$ubicacion = 0; 
		$_REQUEST['municipio'] = 0;
		$municipio = 0;
	}
// define municipio
	if (isset($_REQUEST['municipio'])){ $municipio = $_REQUEST['municipio'];} else { $municipio = 0;}
// define municipio si el tipo de eleccion es 3 o 4
	if ($ubicacion == 0){
		if ($tipoeleccion > 2 && $tipoeleccion < 5){
			$ubicacion = 1;
		}
	}
	if ($municipio == 0){
		if ($tipoeleccion == 4){
			$municipio = 1;
		}
	}
// corrobora que los datos sean numericos y define variables
if (preg_match("/^[0-9]+$/",$tipoeleccion) && preg_match("/^[0-9]+$/",$ubicacion)){
/* inicio de filtro consultas */
	$poner = array('','','','','','','');
	$quitar = array('-','%','<','>','|','_',' ');
	$tipoeleccion=str_replace($quitar,$poner,$tipoeleccion);
	$ubicacion=str_replace($quitar,$poner,$ubicacion);
	$tipoeleccion=substr($tipoeleccion,0,2);
	$ubicacion=substr($ubicacion,0,2);
/* fin de filtro consultas */
} else {
	if (!preg_match("/^[0-9]+$/",$tipoeleccion)){ $tipoeleccion = 1;}
	if (!preg_match("/^[0-9]+$/",$tipoeleccion)){ $ubicacion = 0;}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Resultados 2011, Primera Vuelta, Elecciones Generales y al Parlamento Centroamericano 2011 - Tribunal Supremo Electoral, Guatemala</title>
<link href="css/general.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/highcharts.js"></script>
<script type="text/javascript" src="js/export.js"></script>
</head>
<body>
<div id="contenedor">
	<div id="encabezado">
	</div>
    <div id="contenido">
        <form name="formResultados" id="formResultados" method="post">
            <fieldset class="redondo">
                <legend>Resultados Preliminares - Elecciones 2011.</legend>
                <p>
                    <label>Cargos de elecci&oacute;n Popular</label>
                    <select name="tipoeleccion" id="tipoeleccion" onchange="submit();">
                        <option value="1" <?php if ($tipoeleccion == 1){ $nomTipoeleccion = "Presidente y Vicepresidente"; echo "SELECTED";}?>>Presidente y Vicepresidente</option>
                        <?php /*<option value="2" <?php if ($tipoeleccion == 2){ $nomTipoeleccion = "Diputados por Lista Nacional"; echo "SELECTED";}?>>Diputados por Lista Nacional</option>
                        <option value="3" <?php if ($tipoeleccion == 3){ $nomTipoeleccion = "Diputados por Distrito"; echo "SELECTED";}?>>Diputados por Distrito</option> */?>
                        <option value="4" <?php if ($tipoeleccion == 4){ $nomTipoeleccion = "Corporación Municipal"; echo "SELECTED";}?>>Corporaci&oacute;n Municipal</option>
                        <?php /*<option value="5" <?php if ($tipoeleccion == 5){ $nomTipoeleccion = "Diputados al Parlamento Centroamericano"; echo "SELECTED";}?>>Diputados al Parlamento Centroamericano</option>*/?>
                    </select>
                </p>
                <p>
                    <label>Por ubicaci&oacute;n</label>
                    <select name="ubicacion" id="ubicacion" onchange="submit();">
                    	<? /*if ($tipoeleccion < 3 || $tipoeleccion > 4){*/if ($tipoeleccion == 1){?>
                        <option value="0" <?php if ($ubicacion == 0){ $nomUbicacion = "Todo el Pais"; echo "SELECTED";}?>>Todo el Pais (Nacional)</option>
                        <? }?>
						<?php include('departamentos.php');?>
                    </select>
					<?php if ($ubicacion > 0){?>
                        <select name="municipio" id="municipio" onchange="submit();">
                    	<? if ($tipoeleccion != 4){?>
                            <option value="0" <?php if ($municipio == 0){ $nomUbicacion = "Departamento de ". $nomUbicacion; echo "SELECTED";}?>>Todos los municipios</option>
                        <? }?>
                            <?php include('municipios.php');?>
                        </select>
                    <?php }?>
                </p>
            </fieldset>
        </form>
		<?php
            require_once('../../include/nusoap/nusoap.php');
            $cliente = new nusoap_client('./enlace.php');
            $solicita_estadistica = array('tipoeleccion' => $tipoeleccion, 'ubicacion' => $ubicacion, 'municipio' => $municipio);
            $resultado = $cliente->call('estadisticas', $solicita_estadistica);
        ?>
		<script type="text/javascript">
        var chart1;
        $(document).ready(function() {
            chart1 = new Highcharts.Chart({
				// item 1
                chart: {
					// item 1.1
                    renderTo: 'grafica',
					// item 1.2
                    defaultSeriesType: 'column'
                },
				// item 2
				series: [{
					// item 2.1
					name: '<?php echo $nomTipoeleccion?> - <?php echo $nomUbicacion?><br /><?php echo number_format($resultado['VOTOSVALIDOS'],0,',',',')?> votos validos de <?php echo number_format($resultado['TOTALVOTOS'],0,',',',')?> votos emitidos<br />Un total de <?php echo number_format($resultado['CNTVOTANTES'],0,',',',')?> votantes inscritos<br />en: <?php echo $nomUbicacion?>',
					// item 2.2
                    data: [
                        // candidato 1
                        <?php if (!empty($resultado['S1'])){?>
                            { name: '<?php echo $resultado['S1']?>', color: '#<?php echo $resultado['C1']?>', y: <?php echo $resultado['V1']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S2'])){?>
                            { name: '<?php echo $resultado['S2']?>', color: '#<?php echo $resultado['C2']?>', y: <?php echo $resultado['V2']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S3'])){?>
                            { name: '<?php echo $resultado['S3']?>', color: '#<?php echo $resultado['C3']?>', y: <?php echo $resultado['V3']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S4'])){?>
                            { name: '<?php echo $resultado['S4']?>', color: '#<?php echo $resultado['C4']?>', y: <?php echo $resultado['V4']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S5'])){?>
                            { name: '<?php echo $resultado['S5']?>', color: '#<?php echo $resultado['C5']?>', y: <?php echo $resultado['V5']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S6'])){?>
                            { name: '<?php echo $resultado['S6']?>', color: '#<?php echo $resultado['C6']?>', y: <?php echo $resultado['V6']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S7'])){?>
                            { name: '<?php echo $resultado['S7']?>', color: '#<?php echo $resultado['C7']?>', y: <?php echo $resultado['V7']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S8'])){?>
                            { name: '<?php echo $resultado['S8']?>', color: '#<?php echo $resultado['C8']?>', y: <?php echo $resultado['V8']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S9'])){?>
                            { name: '<?php echo $resultado['S9']?>', color: '#<?php echo $resultado['C9']?>', y: <?php echo $resultado['V9']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S10'])){?>
                            { name: '<?php echo $resultado['S10']?>', color: '#<?php echo $resultado['C10']?>', y: <?php echo $resultado['V10']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S11'])){?>
                            { name: '<?php echo $resultado['S11']?>', color: '#<?php echo $resultado['C11']?>', y: <?php echo $resultado['V11']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S12'])){?>
                            { name: '<?php echo $resultado['S12']?>', color: '#<?php echo $resultado['C12']?>', y: <?php echo $resultado['V12']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S13'])){?>
                            { name: '<?php echo $resultado['S13']?>', color: '#<?php echo $resultado['C13']?>', y: <?php echo $resultado['V13']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S14'])){?>
                            { name: '<?php echo $resultado['S14']?>', color: '#<?php echo $resultado['C14']?>', y: <?php echo $resultado['V14']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S15'])){?>
                            { name: '<?php echo $resultado['S15']?>', color: '#<?php echo $resultado['C15']?>', y: <?php echo $resultado['V15']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S16'])){?>
                            { name: '<?php echo $resultado['S16']?>', color: '#<?php echo $resultado['C16']?>', y: <?php echo $resultado['V16']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S17'])){?>
                            { name: '<?php echo $resultado['S17']?>', color: '#<?php echo $resultado['C17']?>', y: <?php echo $resultado['V17']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S18'])){?>
                            { name: '<?php echo $resultado['S18']?>', color: '#<?php echo $resultado['C18']?>', y: <?php echo $resultado['V18']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S19'])){?>
                            { name: '<?php echo $resultado['S19']?>', color: '#<?php echo $resultado['C19']?>', y: <?php echo $resultado['V19']?>},
                        <?php }?>
                        <?php if (!empty($resultado['S20'])){?>
                            { name: '<?php echo $resultado['S20']?>', color: '#<?php echo $resultado['C20']?>', y: <?php echo $resultado['V20']?>},
                        <?php }?>
                        <?php if (!empty($resultado['NULOS'])){?>
                            { name: 'VOTOS NULOS', color: '#BBBBBB', y: <?php echo $resultado['NULOS']?>},
                        <?php }?>
                        <?php if (!empty($resultado['BLANCOS'])){?>
                            { name: 'VOTOS EN BLANCO', color: '#FFFFFF', y: <?php echo $resultado['BLANCOS']?>},
                        <?php }?>
                        <?php if (!empty($resultado['ABSTENCIONISMO'])){?>
                            { name: 'ABSTENCIONISMO <?=number_format($resultado['ABSTENCIONISMO'],0,',',',')?>', color: '#DEDEDE', y: <?php echo $resultado['ABSTENCIONISMO']?>},
                        <?php }?>
                    ]
                }],
				// item 3
                title: {
					// item 3.1
                    text: 'Resultados Preliminares - Primera Vuelta'
                },
				// item 4
                xAxis: {
					// item 4.1
                    categories: [
                        <?php if (!empty($resultado['S1'])){?>
                        '<?php echo $resultado['S1']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S2'])){?>
                        '<?php echo $resultado['S2']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S3'])){?>
                        '<?php echo $resultado['S3']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S4'])){?>
                        '<?php echo $resultado['S4']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S5'])){?>
                        '<?php echo $resultado['S5']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S6'])){?>
                        '<?php echo $resultado['S6']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S7'])){?>
                        '<?php echo $resultado['S7']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S8'])){?>
                        '<?php echo $resultado['S8']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S9'])){?>
                        '<?php echo $resultado['S9']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S10'])){?>
                        '<?php echo $resultado['S10']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S11'])){?>
                        '<?php echo $resultado['S11']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S12'])){?>
                        '<?php echo $resultado['S12']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S13'])){?>
                        '<?php echo $resultado['S13']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S14'])){?>
                        '<?php echo $resultado['S14']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S15'])){?>
                        '<?php echo $resultado['S15']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S16'])){?>
                        '<?php echo $resultado['S16']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S17'])){?>
                        '<?php echo $resultado['S17']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S18'])){?>
                        '<?php echo $resultado['S18']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S19'])){?>
                        '<?php echo $resultado['S19']?>',
                        <?php }?>
                        <?php if (!empty($resultado['S20'])){?>
                        '<?php echo $resultado['S20']?>',
                        <?php }?>
                        <?php if (!empty($resultado['NULOS'])){?>
                        'VOTOS NULOS',
                        <?php }?>
                        <?php if (!empty($resultado['BLANCOS'])){?>
                        'VOTOS EN BLANCO',
                        <?php }?>
                        <?php if (!empty($resultado['ABSTENCIONISMO'])){?>
                        'ABSTENCIONISMO',
                        <?php }?>
                    ],
					// item 4.2
					labels : {
						align: 'right',
						rotation : 315,
						x: 5,
						y: 10
					},
                },
				// item 5
				yAxis: {
					title: {
						text: 'Votos recibidos'
					}
				},
				// item 6
                plotOptions: {
					// item 6.1
                    series: {
						// item 6.1.1
                        dataLabels: {
                            align: 'right',
							rotation: 315,
							x: 0,
							y: -15,
							formatter: function() {
                    			return Math.floor((((this.y*100)/7340841)*100)/100) +'%';
                			},
                            enabled: true
                        },
						// item 6.1.2
						pointWidth: 20
					},
					// item 6.2
					animation: {
						duration: 2000,
						easing: 'easeOutBounce'
					}
                },
            });
        });
        </script>    
		<div id="grafica" style="min-height:600px; max-height:800px;"></div>
        <div id="indicaciones">
        	<p>En el despliegue de resultados se entiende que:</p>
            <ul>
            	<li>Las cifras son de car&aacute;cter preliminar mientras no se hayan computado la totalidad de las actas de escrutinio de las Juntas Receptoras de Votos (JRV).</li>
                <li>Votos v&aacute;lidos es la suma de los votos obtenidos por los partidos, sin considerar votos blancos ni nulos.</li>
                <li>La suma de v&aacute;lidos, blancos y nulos es el total de votos emitidos.</li>
                <li>El total de votantes inscritos se refiere al n&uacute;mero de votantes que se han inscrito en el Padr&oacute;n Electoral para todas las mesas.</li>
            </ul>
        </div>
	</div>
    <div id="pie" class="redondo">
    	<p>&copy; Tribunal Supremo Electoral | Guatemala, Centro&aacute;merica 2011</p>
    </div>
</div>
</body>
</html>