<?php
require_once('../../include/nusoap/nusoap.php');
require_once('../../include/nusoap/estadisticas.php');
$server = new nusoap_server();
$server->register('estadisticas',
	array('tipoeleccion' => 'xsd:int', 'ubicacion' => 'xsd:string', 'municipio' => 'xsd:int')
);
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>