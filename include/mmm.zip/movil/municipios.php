<?php switch ($ubicacion){
	case 1:?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Distrito Central, ". $nomUbicacion; echo "SELECTED";}?>>Distrito Central</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Santa Catarina Pinula, ". $nomUbicacion; echo "SELECTED";}?>>Santa Catarina Pinula</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "San José Pinula, ". $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute; Pinula</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San José del Golfo, ". $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute; del Golfo</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Palencia, ". $nomUbicacion; echo "SELECTED";}?>>Palencia</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Chinautla, ". $nomUbicacion; echo "SELECTED";}?>>Chinautla</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "San Pedro Ayampuc, ". $nomUbicacion; echo "SELECTED";}?>>San Pedro Ayampuc</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "San Pedro Sacatepéquez, " . $nomUbicacion; echo "SELECTED";}?>>San Pedro Sacatep&eacute;quez</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "San Juan Sacatepéquez, " . $nomUbicacion; echo "SELECTED";}?>>San Juan Sacatep&eacute;quez</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "San Raimundo, " . $nomUbicacion; echo "SELECTED";}?>>San Raimundo</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Chuarrancho, " . $nomUbicacion; echo "SELECTED";}?>>Chuarrancho</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Fraijanes, " . $nomUbicacion; echo "SELECTED";}?>>Fraijanes</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Amatitlán, " . $nomUbicacion; echo "SELECTED";}?>>Amatitl&aacute;n</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Villa Nueva, " . $nomUbicacion; echo "SELECTED";}?>>Villa Nueva</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Villa Canales, " . $nomUbicacion; echo "SELECTED";}?>>Villa Canales</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Petapa, " . $nomUbicacion; echo "SELECTED";}?>>Petapa</option>
<?php
	break;
	case 2:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Antigua Guatemala, " . $nomUbicacion; echo "SELECTED";}?>>Antigua Guatemala</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Jocotenango, " . $nomUbicacion; echo "SELECTED";}?>>Jocotenango</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Pastores, " . $nomUbicacion; echo "SELECTED";}?>>Pastores</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Sumpango, " . $nomUbicacion; echo "SELECTED";}?>>Sumpango</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Santo Domingo Xenacoj, " . $nomUbicacion; echo "SELECTED";}?>>Santo Domingo Xenacoj</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Santiago Sacatepéquez, " . $nomUbicacion; echo "SELECTED";}?>>Santiago Sacatep&eacute;quez</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "San Bartolomé Milpas Altas, " . $nomUbicacion; echo "SELECTED";}?>>San Bartolom&eacute; Milpas Altas</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "San Lucas Sacatepéquez, " . $nomUbicacion; echo "SELECTED";}?>>San Lucas Sacatep&eacute;quez</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Santa Lucía Milpas Altas, " . $nomUbicacion; echo "SELECTED";}?>>Santa Luc&iacute;a Milpas Altas</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Magdalena Milpas Altas, " . $nomUbicacion; echo "SELECTED";}?>>Magdalena Milpas Altas</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Santa María de Jesús, " . $nomUbicacion; echo "SELECTED";}?>>Santa Mar&iacute;a de Jes&uacute;s</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Ciudad Vieja, " . $nomUbicacion; echo "SELECTED";}?>>Ciudad Vieja</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "San Miguel Dueñas, " . $nomUbicacion; echo "SELECTED";}?>>San Miguel Due&ntilde;as</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Alotenango, " . $nomUbicacion; echo "SELECTED";}?>>Alotenango</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "San Antonio Aguas Calientes, " . $nomUbicacion; echo "SELECTED";}?>>San Antonio Aguas Calientes</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Santa Catarina Barahona, " . $nomUbicacion; echo "SELECTED";}?>>Santa Catarina Barahona</option>
    <?php
	break;
	case 3:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Chimaltenango, " . $nomUbicacion; echo "SELECTED";}?>>Chimaltenango</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "San José Poaquil, " . $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute; Poaquil</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "San Martín Jilotepeque, " . $nomUbicacion; echo "SELECTED";}?>>San Mart&iacute;n Jilotepeque</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Comalapa, " . $nomUbicacion; echo "SELECTED";}?>>Comalapa</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Santa Apolonia, " . $nomUbicacion; echo "SELECTED";}?>>Santa Apolonia</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Tecpán Guatemala, " . $nomUbicacion; echo "SELECTED";}?>>Tecp&aacute;n Guatemala</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Patzún, " . $nomUbicacion; echo "SELECTED";}?>>Patz&uacute;n</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Pochuta, " . $nomUbicacion; echo "SELECTED";}?>>Pochuta</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Patzicía, " . $nomUbicacion; echo "SELECTED";}?>>Patzic&iacute;a</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Santa Cruz Balanyá, " . $nomUbicacion; echo "SELECTED";}?>>Santa Cruz Balany&aacute;</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Acatenango, " . $nomUbicacion; echo "SELECTED";}?>>Acatenango</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Yepocapa, " . $nomUbicacion; echo "SELECTED";}?>>Yepocapa</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "San andrés Itzapa, " . $nomUbicacion; echo "SELECTED";}?>>San andr&eacute;s Itzapa</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Parramos, " . $nomUbicacion; echo "SELECTED";}?>>Parramos</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Zaragoza, " . $nomUbicacion; echo "SELECTED";}?>>Zaragoza</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "El Tejar, " . $nomUbicacion; echo "SELECTED";}?>>El Tejar</option>
    <?php
	break;
	case 4:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Guastatoya, " . $nomUbicacion; echo "SELECTED";}?>>Guastatoya</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Morazán, " . $nomUbicacion; echo "SELECTED";}?>>Moraz&aacute;n</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "San Agustín Acasaguastlán, " . $nomUbicacion; echo "SELECTED";}?>>San Agust&iacute;n Acasaguastl&aacute;n</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San Cristóbal Acasaguastlán, " . $nomUbicacion; echo "SELECTED";}?>>San Crist&oacute;bal Acasaguastl&aacute;n</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "El Jícaro, " . $nomUbicacion; echo "SELECTED";}?>>El J&iacute;caro</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Sansare, " . $nomUbicacion; echo "SELECTED";}?>>Sansare</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Sanarate, " . $nomUbicacion; echo "SELECTED";}?>>Sanarate</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "San Antonio La Paz, " . $nomUbicacion; echo "SELECTED";}?>>San Antonio La Paz</option>
    <?php
	break;
	case 5:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Escuintla, " . $nomUbicacion; echo "SELECTED";}?>>Escuintla</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Santa Lucía Cotzumalguapa, " . $nomUbicacion; echo "SELECTED";}?>>Santa Luc&iacute;a Cotzumalguapa</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "La Democracia, " . $nomUbicacion; echo "SELECTED";}?>>La Democracia</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Siquinalá, " . $nomUbicacion; echo "SELECTED";}?>>Siquinal&aacute;</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Masagua, " . $nomUbicacion; echo "SELECTED";}?>>Masagua</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Tiquisate, " . $nomUbicacion; echo "SELECTED";}?>>Tiquisate</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "La Gomera, " . $nomUbicacion; echo "SELECTED";}?>>La Gomera</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Guanagazapa, " . $nomUbicacion; echo "SELECTED";}?>>Guanagazapa</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "San José, " . $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute;</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Iztapa, " . $nomUbicacion; echo "SELECTED";}?>>Iztapa</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Palín, " . $nomUbicacion; echo "SELECTED";}?>>Pal&iacute;n</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "San Vicente Pacaya, " . $nomUbicacion; echo "SELECTED";}?>>San Vicente Pacaya</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Nueva Concepción, " . $nomUbicacion; echo "SELECTED";}?>>Nueva Concepci&oacute;n</option>
    <?php
	break;
	case 6:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Cuilapa, " . $nomUbicacion; echo "SELECTED";}?>>Cuilapa</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Barberena, " . $nomUbicacion; echo "SELECTED";}?>>Barberena</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Santa Rosa de Lima, " . $nomUbicacion; echo "SELECTED";}?>>Santa Rosa de Lima</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Casillas, " . $nomUbicacion; echo "SELECTED";}?>>Casillas</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "San Rafael Las Flores, " . $nomUbicacion; echo "SELECTED";}?>>San Rafael Las Flores</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Oratorio, " . $nomUbicacion; echo "SELECTED";}?>>Oratorio</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "San Juan Tecuaco, " . $nomUbicacion; echo "SELECTED";}?>>San Juan Tecuaco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Chiquimulilla, " . $nomUbicacion; echo "SELECTED";}?>>Chiquimulilla</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Taxisco, " . $nomUbicacion; echo "SELECTED";}?>>Taxisco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Santa María Ixhuatán, " . $nomUbicacion; echo "SELECTED";}?>>Santa Mar&iacute;a Ixhuat&aacute;n</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Guazacapán, " . $nomUbicacion; echo "SELECTED";}?>>Guazacap&aacute;n</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Santa Cruz Naranjo, " . $nomUbicacion; echo "SELECTED";}?>>Santa Cruz Naranjo</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Pueblo Nuevo Viñas, " . $nomUbicacion; echo "SELECTED";}?>>Pueblo Nuevo Vi&ntilde;as</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Nueva Santa Rosa, " . $nomUbicacion; echo "SELECTED";}?>>Nueva Santa Rosa</option>
    <?php
	break;
	case 7:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Sololá, " . $nomUbicacion; echo "SELECTED";}?>>Solol&aacute;</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "San José Chacayá, " . $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute; Chacay&aacute;</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Santa María Visitación, " . $nomUbicacion; echo "SELECTED";}?>>Santa Mar&iacute;a Visitaci&oacute;n</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Santa Lucía Utatlán, " . $nomUbicacion; echo "SELECTED";}?>>Santa Luc&iacute;a Utatl&aacute;n</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Nahualá, " . $nomUbicacion; echo "SELECTED";}?>>Nahual&aacute;</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Santa Catarina Ixtahuacán, " . $nomUbicacion; echo "SELECTED";}?>>Santa Catarina Ixtahuac&aacute;n</option>    
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Santa Clara La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>Santa Clara La Laguna</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Concepción, " . $nomUbicacion; echo "SELECTED";}?>>Concepci&oacute;n</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "San Andrés Semetabaj, " . $nomUbicacion; echo "SELECTED";}?>>San Andr&eacute;s Semetabaj</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Panajachel, " . $nomUbicacion; echo "SELECTED";}?>>Panajachel</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Santa Catarina Palopó, " . $nomUbicacion; echo "SELECTED";}?>>Santa Catarina Palop&oacute;</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "San Antonio Palopó, " . $nomUbicacion; echo "SELECTED";}?>>San Antonio Palop&oacute;</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "San Lucas Tolimán, " . $nomUbicacion; echo "SELECTED";}?>>San Lucas Tolim&aacute;n</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Santa Cruz La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>Santa Cruz La Laguna</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "San Pablo La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>San Pablo La Laguna</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "San Marcos La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>San Marcos La Laguna</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "San Juan La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>San Juan La Laguna</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "San Pedro La Laguna, " . $nomUbicacion; echo "SELECTED";}?>>San Pedro La Laguna</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "Santiago atitlán, " . $nomUbicacion; echo "SELECTED";}?>>Santiago atitl&aacute;n</option>
	    <?php
	break;
	case 8:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Totonicapán, " . $nomUbicacion; echo "SELECTED";}?>>Totonicap&aacute;n</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "San Cristóbal Totonicapán, " . $nomUbicacion; echo "SELECTED";}?>>San Crist&oacute;bal Totonicap&aacute;n</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "San Francisco El Alto, " . $nomUbicacion; echo "SELECTED";}?>>San Francisco El Alto</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San Andr&eacute;s Xecul, " . $nomUbicacion; echo "SELECTED";}?>>San Andr&eacute;s Xecul</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Momostenango, " . $nomUbicacion; echo "SELECTED";}?>>Momostenango</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Santa María Chiquimula, " . $nomUbicacion; echo "SELECTED";}?>>Santa Mar&iacute;a Chiquimula</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Santa Lucía La Reforma, " . $nomUbicacion; echo "SELECTED";}?>>Santa Luc&iacute;a La Reforma</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "San Bartolo, " . $nomUbicacion; echo "SELECTED";}?>>San Bartolo</option>
    <?php
	break;
	case 9:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Quetzaltenango, " . $nomUbicacion; echo "SELECTED";}?>>Quetzaltenango</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Salcajá, " . $nomUbicacion; echo "SELECTED";}?>>Salcaj&aacute;</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Olintepeque, " . $nomUbicacion; echo "SELECTED";}?>>Olintepeque</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San Carlos Sija, " . $nomUbicacion; echo "SELECTED";}?>>San Carlos Sija</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Sibilia, " . $nomUbicacion; echo "SELECTED";}?>>Sibilia</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Cabric&aacute;n, " . $nomUbicacion; echo "SELECTED";}?>>Cabric&aacute;n</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Cajolá, " . $nomUbicacion; echo "SELECTED";}?>>Cajol&aacute;</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "San Miguel Sigüilá, " . $nomUbicacion; echo "SELECTED";}?>>San Miguel Sig&uuml;il&aacute;</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Ostuncalco, " . $nomUbicacion; echo "SELECTED";}?>>Ostuncalco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "San Mateo, " . $nomUbicacion; echo "SELECTED";}?>>San Mateo</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Concepción Chiquirichapa, " . $nomUbicacion; echo "SELECTED";}?>>Concepci&oacute;n Chiquirichapa</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "San Martón Sacatepéquez, " . $nomUbicacion; echo "SELECTED";}?>>San Mart&iacute;n Sacatep&eacute;quez</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Almolonga, " . $nomUbicacion; echo "SELECTED";}?>>Almolonga</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Cantel, " . $nomUbicacion; echo "SELECTED";}?>>Cantel</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Huitán, " . $nomUbicacion; echo "SELECTED";}?>>Huit&aacute;n</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Zunil, " . $nomUbicacion; echo "SELECTED";}?>>Zunil</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Colomba, " . $nomUbicacion; echo "SELECTED";}?>>Colomba</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "San Francisco La Unión, " . $nomUbicacion; echo "SELECTED";}?>>San Francisco La Uni&oacute;n</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "El Palmar, " . $nomUbicacion; echo "SELECTED";}?>>El Palmar</option>
    <option value="20" <?php if ($municipio == 20){ $nomUbicacion = "Coatepeque, " . $nomUbicacion; echo "SELECTED";}?>>Coatepeque</option>
    <option value="21" <?php if ($municipio == 21){ $nomUbicacion = "Génova, " . $nomUbicacion; echo "SELECTED";}?>>G&eacute;nova</option>
    <option value="22" <?php if ($municipio == 22){ $nomUbicacion = "Flores Costa Cuca, " . $nomUbicacion; echo "SELECTED";}?>>Flores Costa Cuca</option>
    <option value="23" <?php if ($municipio == 23){ $nomUbicacion = "La Esperanza, " . $nomUbicacion; echo "SELECTED";}?>>La Esperanza</option>
    <option value="24" <?php if ($municipio == 24){ $nomUbicacion = "Palestina de Los Altos, " . $nomUbicacion; echo "SELECTED";}?>>Palestina de Los Altos</option>
    <?
	break;
	case 10:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mazatenango, " . $nomUbicacion; echo "SELECTED";}?>>Mazatenango</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Cuyotenango, " . $nomUbicacion; echo "SELECTED";}?>>Cuyotenango</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "San Francisco Zapotitlán, " . $nomUbicacion; echo "SELECTED";}?>>San Francisco Zapotitl&aacute;n</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San Bernardino, " . $nomUbicacion; echo "SELECTED";}?>>San Bernardino</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "San José el Ídolo, " . $nomUbicacion; echo "SELECTED";}?>>San Jos&eacute; el &Iacute;dolo</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Santo Domingo Suchitepéquez, " . $nomUbicacion; echo "SELECTED";}?>>Santo Domingo Suchitep&eacute;quez</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "San Lorenzo, " . $nomUbicacion; echo "SELECTED";}?>>San Lorenzo</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Samayac, " . $nomUbicacion; echo "SELECTED";}?>>Samayac</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "San Pablo Jocopilas, " . $nomUbicacion; echo "SELECTED";}?>>San Pablo Jocopilas</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "San Antonio Suchitepéquez, " . $nomUbicacion; echo "SELECTED";}?>>San Antonio Suchitep&eacute;quez</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "San Miguel Panán, " . $nomUbicacion; echo "SELECTED";}?>>San Miguel Pan&aacute;n</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "San Gabriel, " . $nomUbicacion; echo "SELECTED";}?>>San Gabriel</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Chicacao, " . $nomUbicacion; echo "SELECTED";}?>>Chicacao</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Patulul, " . $nomUbicacion; echo "SELECTED";}?>>Patulul</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Santa Bárbara, " . $nomUbicacion; echo "SELECTED";}?>>Santa B&aacute;rbara</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "San Juan Bautista, " . $nomUbicacion; echo "SELECTED";}?>>San Juan Bautista</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Santo Tomás La Unión, " . $nomUbicacion; echo "SELECTED";}?>>Santo Tom&aacute;s La Uni&oacute;n</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "Zunilito, " . $nomUbicacion; echo "SELECTED";}?>>Zunilito</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "Pueblo Nuevo, " . $nomUbicacion; echo "SELECTED";}?>>Pueblo Nuevo</option>
    <option value="20" <?php if ($municipio == 20){ $nomUbicacion = "R&iacute;o Bravo, " . $nomUbicacion; echo "SELECTED";}?>>R&iacute;o Bravo</option>
    <?
	break;
	case 11:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Retalhuleu, " . $nomUbicacion; echo "SELECTED";}?>>Retalhuleu</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "San Sebastián, " . $nomUbicacion; echo "SELECTED";}?>>San Sebasti&aacute;n</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Santa Cruz Muluá, " . $nomUbicacion; echo "SELECTED";}?>>Santa Cruz Mulu&aacute;</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "San Martín Zapotitlán, " . $nomUbicacion; echo "SELECTED";}?>>San Mart&iacute;n Zapotitl&aacute;n</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "San Felipe, " . $nomUbicacion; echo "SELECTED";}?>>San Felipe</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "San Andrés Villa Seca, " . $nomUbicacion; echo "SELECTED";}?>>San Andr&eacute;s Villa Seca</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Champerico, " . $nomUbicacion; echo "SELECTED";}?>>Champerico</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Nuevo San Carlos, " . $nomUbicacion; echo "SELECTED";}?>>Nuevo San Carlos</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "El Asintal, " . $nomUbicacion; echo "SELECTED";}?>>El Asintal</option>
    <?
	break;
	case 12:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="20" <?php if ($municipio == 20){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="21" <?php if ($municipio == 21){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="22" <?php if ($municipio == 22){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="23" <?php if ($municipio == 23){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="24" <?php if ($municipio == 24){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="25" <?php if ($municipio == 25){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="26" <?php if ($municipio == 26){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="27" <?php if ($municipio == 27){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="28" <?php if ($municipio == 28){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="29" <?php if ($municipio == 29){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 13:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="20" <?php if ($municipio == 20){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="21" <?php if ($municipio == 21){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="22" <?php if ($municipio == 22){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="23" <?php if ($municipio == 23){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="24" <?php if ($municipio == 24){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="25" <?php if ($municipio == 25){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="26" <?php if ($municipio == 26){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="27" <?php if ($municipio == 27){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="28" <?php if ($municipio == 28){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="29" <?php if ($municipio == 29){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="30" <?php if ($municipio == 30){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="31" <?php if ($municipio == 31){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="32" <?php if ($municipio == 32){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 14:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="18" <?php if ($municipio == 18){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="19" <?php if ($municipio == 19){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="20" <?php if ($municipio == 20){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="21" <?php if ($municipio == 21){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 15:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 16:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 17:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 18:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 19:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 20:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 21:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
	case 22:
	?>
    <option value="1" <?php if ($municipio == 1){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="2" <?php if ($municipio == 2){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="3" <?php if ($municipio == 3){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="4" <?php if ($municipio == 4){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="5" <?php if ($municipio == 5){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="6" <?php if ($municipio == 6){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="7" <?php if ($municipio == 7){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="8" <?php if ($municipio == 8){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="9" <?php if ($municipio == 9){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="10" <?php if ($municipio == 10){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="11" <?php if ($municipio == 11){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="12" <?php if ($municipio == 12){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="13" <?php if ($municipio == 13){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="14" <?php if ($municipio == 14){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="15" <?php if ($municipio == 15){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="16" <?php if ($municipio == 16){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <option value="17" <?php if ($municipio == 17){ $nomUbicacion = "Mixco, " . $nomUbicacion; echo "SELECTED";}?>>Mixco</option>
    <?
	break;
}
?>