<?php
switch($tipoeleccion){
	case 1:
	?>
<option value="1" <?php if ($ubicacion == 1){ $nomUbicacion = "Guatemala (depto)"; echo "SELECTED";}?>>Guatemala (depto.)</option>
<option value="2" <?php if ($ubicacion == 2){ $nomUbicacion = "Sacatepéquez"; echo "SELECTED";}?>>Sacatep&eacute;quez</option>
<option value="3" <?php if ($ubicacion == 3){ $nomUbicacion = "Chimaltenango"; echo "SELECTED";}?>>Chimaltenango</option>
<option value="4" <?php if ($ubicacion == 4){ $nomUbicacion = "El Progreso"; echo "SELECTED";}?>>El Progreso</option>
<option value="5" <?php if ($ubicacion == 5){ $nomUbicacion = "Escuintla"; echo "SELECTED";}?>>Escuintla</option>
<option value="6" <?php if ($ubicacion == 6){ $nomUbicacion = "Santa Rosa"; echo "SELECTED";}?>>Santa Rosa</option>
<option value="7" <?php if ($ubicacion == 7){ $nomUbicacion = "Sololá"; echo "SELECTED";}?>>Solol&aacute;</option>
<option value="8" <?php if ($ubicacion == 8){ $nomUbicacion = "Totonicapán"; echo "SELECTED";}?>>Totonicap&aacute;n</option>
<option value="9" <?php if ($ubicacion == 9){ $nomUbicacion = "Quetzaltenango"; echo "SELECTED";}?>>Quetzaltenango</option>
<option value="10" <?php if ($ubicacion == 10){ $nomUbicacion = "Suchitepéquez"; echo "SELECTED";}?>>Suchitep&eacute;quez</option>
<option value="11" <?php if ($ubicacion == 11){ $nomUbicacion = "Retalhuleu"; echo "SELECTED";}?>>Retalhuleu</option>
<option value="12" <?php if ($ubicacion == 12){ $nomUbicacion = "San Marcos"; echo "SELECTED";}?>>San Marcos</option>
<option value="13" <?php if ($ubicacion == 13){ $nomUbicacion = "Huehuetenango"; echo "SELECTED";}?>>Huehuetenango</option>
<option value="14" <?php if ($ubicacion == 14){ $nomUbicacion = "Quiché"; echo "SELECTED";}?>>Quich&eacute;</option>
<option value="15" <?php if ($ubicacion == 15){ $nomUbicacion = "Baja Verapaz"; echo "SELECTED";}?>>Baja Verapaz</option>
<option value="16" <?php if ($ubicacion == 16){ $nomUbicacion = "Alta Verapaz"; echo "SELECTED";}?>>Alta Verapaz</option>
<option value="17" <?php if ($ubicacion == 17){ $nomUbicacion = "Petén"; echo "SELECTED";}?>>Pet&eacute;n</option>
<option value="18" <?php if ($ubicacion == 18){ $nomUbicacion = "Izabal"; echo "SELECTED";}?>>Izabal</option>
<option value="19" <?php if ($ubicacion == 19){ $nomUbicacion = "Zacapa"; echo "SELECTED";}?>>Zacapa</option>
<option value="20" <?php if ($ubicacion == 20){ $nomUbicacion = "Chiquimula"; echo "SELECTED";}?>>Chiquimula</option>
<option value="21" <?php if ($ubicacion == 21){ $nomUbicacion = "Jalapa"; echo "SELECTED";}?>>Jalapa</option>
<option value="22" <?php if ($ubicacion == 22){ $nomUbicacion = "Jutiapa"; echo "SELECTED";}?>>Jutiapa</option>
	<?
	break;
	case 4:
	?>
<option value="6" <?php if ($ubicacion == 6){ $nomUbicacion = "Santa Rosa"; echo "SELECTED";}?>>Santa Rosa</option>
<option value="13" <?php if ($ubicacion == 13){ $nomUbicacion = "Huehuetenango"; echo "SELECTED";}?>>Huehuetenango</option>
<option value="14" <?php if ($ubicacion == 14){ $nomUbicacion = "Quiché"; echo "SELECTED";}?>>Quich&eacute;</option>
<option value="17" <?php if ($ubicacion == 17){ $nomUbicacion = "Petén"; echo "SELECTED";}?>>Pet&eacute;n</option>
<option value="18" <?php if ($ubicacion == 18){ $nomUbicacion = "Izabal"; echo "SELECTED";}?>>Izabal</option>
	<?
	break;
}
?>